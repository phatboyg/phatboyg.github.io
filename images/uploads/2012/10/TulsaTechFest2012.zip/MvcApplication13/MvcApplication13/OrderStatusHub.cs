﻿namespace MvcApplication13
{
    using System.Threading.Tasks;
    using Magnum.Extensions;
    using MassTransit;
    using MessageContracts;
    using SignalR.Hubs;

    public class OrderStatusHub :
        Hub
    {
        public Task<OrderStatus> QueryOrderStatus(string orderId)
        {
            Task<OrderStatus> task = null;
            Bus.Instance.PublishRequestAsync(new QueryOrderStatusMessage(orderId), x =>
                {
                    task = x.Handle<OrderStatus>(msg =>
                        {
                            Groups.Add(Context.ConnectionId, orderId);
                        });
                    x.SetTimeout(30.Seconds());
                });

            return task;
        }

        class QueryOrderStatusMessage :
            QueryOrderStatus
        {
            public QueryOrderStatusMessage(string orderId)
            {
                OrderId = orderId;
            }

            public string OrderId { get; private set; }
        }
    }
}