namespace Ordering
{
    using MassTransit;
    using Topshelf;

    class OrderService :
        ServiceControl
    {
        IServiceBus _bus;

        public bool Start(HostControl hostControl)
        {
            _bus = ServiceBusFactory.New(x =>
                {
                    x.ReceiveFrom("rabbitmq://localhost/ttf_service");
                    x.UseRabbitMqRouting();

                    x.Subscribe(s => { s.Consumer<OrderConsumer>(); });
                });

            return true;
        }

        public bool Stop(HostControl hostControl)
        {
            _bus.Dispose();

            return true;
        }
    }
}