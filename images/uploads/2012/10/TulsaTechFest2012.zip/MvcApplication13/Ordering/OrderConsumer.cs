namespace Ordering
{
    using System;
    using System.Threading;
    using System.Threading.Tasks;
    using Magnum.Extensions;
    using MassTransit;
    using MessageContracts;

    class OrderConsumer :
        Consumes<QueryOrderStatus>.Context
    {
        public void Consume(IConsumeContext<QueryOrderStatus> context)
        {
            var orderId = context.Message.OrderId;

            Console.WriteLine("QueryOrderStatus: {0}", orderId);

            context.Respond(new OrderStatusMessage(orderId, "Pending"));

            var bus = context.Bus;

            Task.Factory.StartNew(() =>
                {
                    Thread.Sleep(10.Seconds());

                    Console.WriteLine("Updating Order Status: {0}", orderId);

                    bus.Publish(new OrderStatusMessage(orderId, "Complete"));
                });
        }

        class OrderStatusMessage :
            OrderStatus
        {
            public OrderStatusMessage(string orderId, string status)
            {
                OrderId = orderId;
                Status = status;
            }

            public string OrderId { get; private set; }
            public string Status { get; private set; }
        }
    }
}