namespace MessageContracts
{
    public interface OrderStatus
    {
        string OrderId { get; }
        string Status { get; }
    }
}