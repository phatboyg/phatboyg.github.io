﻿namespace MessageContracts
{
    public interface QueryOrderStatus
    {
        string OrderId { get; }
    }
}