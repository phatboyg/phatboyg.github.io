﻿namespace Messages
{
    public interface LocationResult
    {
        string TruckId { get; }
        int X { get; }
        int Y { get; }
    }
}