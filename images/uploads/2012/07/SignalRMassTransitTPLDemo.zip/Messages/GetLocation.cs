﻿namespace Messages
{
    public interface GetLocation
    {
        string TruckId { get; }    
    }
}