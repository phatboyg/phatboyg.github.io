﻿namespace Messages
{
    public interface AddActionItem
    {
        string Subject { get; }
         
    }
}