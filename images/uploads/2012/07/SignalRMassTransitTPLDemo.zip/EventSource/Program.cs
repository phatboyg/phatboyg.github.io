﻿namespace EventSource
{
    using System;
    using MassTransit;
    using Messages;

    class Program
    {
        static void Main(string[] args)
        {
            using (var bus = ServiceBusFactory.New(x =>
                {
                    x.UseRabbitMqRouting();
                    x.ReceiveFrom("rabbitmq://localhost/fsdnug_source");

                    x.Subscribe(s =>
                        {
                            s.Handler<GetLocation>((context, message) =>
                                {
                                    context.Respond(new LocationResultImpl
                                        {
                                            TruckId = message.TruckId,
                                            X = 1,
                                            Y = 0,
                                        });
                                });
                        });
                }))
            {


                while(true)
                {
                    Console.Write("> ");
                    string subject = Console.ReadLine();

                    bus.Publish(new AddActionItemImpl
                        {
                            Subject = subject,
                        });
                }
            }
        }

        class LocationResultImpl :
            LocationResult
        {
            public string TruckId { get;  set; }
            public int X { get;  set; }
            public int Y { get;  set; }
        }

        class AddActionItemImpl :
            AddActionItem
        {
            public string Subject { get; set; }
        }
    }
}