﻿namespace MvcApplication8
{
    using System.Threading.Tasks;
    using Magnum.Extensions;
    using MassTransit;
    using Messages;
    using SignalR.Hubs;

    public class Location :
        Hub
    {
        public Task<LocationResult> GetLocation(string truckId)
        {
            Task<LocationResult> task = null;
            Bus.Instance.PublishRequestAsync(new GetLocationImpl {TruckId = truckId,}, x =>
                {
                    task = x.Handle<LocationResult>(message => { });
                    x.SetTimeout(30.Seconds());
                });

            return task;
        }

        class GetLocationImpl :
            GetLocation
        {
            public string TruckId { get; set; }
        }
    }
}