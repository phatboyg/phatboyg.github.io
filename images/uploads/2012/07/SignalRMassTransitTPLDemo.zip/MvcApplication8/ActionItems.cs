﻿namespace MvcApplication8
{
    using System.Collections.Generic;
    using System.Linq;
    using SignalR.Hubs;

    public class ActionItems :
        Hub
    {
        static readonly IList<string> _items = new List<string>();

        public void Add(string subject)
        {
            _items.Add(subject);

            Clients.itemAdded(subject);
        }

        public string[] Hello()
        {
            return _items.ToArray();
        }
         
    }
}