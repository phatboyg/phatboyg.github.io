﻿// File Header Text
// Goes Here
#region Yuck
namespace MvcApplication8
{
    using System;
    using System.Text.RegularExpressions;

    /// <summary>
    /// This is a stupid class, but colorful and uses <typeparam name="T">T</typeparam> to make it work.
    /// </summary>
    public class ColorClass<T> :
        IDisposable
        where T : class
    {
        static int _x;

        delegate void Reboot();

        static ColorClass()
        {
            _x = 25;
        }

        /// <summary>
        /// Need to make this beautiful
        /// </summary>
        public ColorClass()
        {
            string message = "The time is now " + DateTime.Now.ToShortTimeString();
            string result = string.Format("Write To {0}", message);

            Regex Operator = new Regex(@"\s.*", RegexOptions.IgnoreCase);

            Reboot rebooter = () => { };

            int total = 0;
            for (int i = 0; i < 1000; i++)
            {
                total += i;

                var value = (i%3)*((i/1) ^ 2) - 5;
                if(value == total)
                {
                    // what the heck?
                    Console.WriteLine("No Freaking Idea: " + value);
                }
            }
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}
#endregion
