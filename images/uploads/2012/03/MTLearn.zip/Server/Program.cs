﻿namespace Server
{
    using System;
    using MassTransit;
    using MassTransit.Saga;

    class Program
    {
        static void Main(string[] args)
        {

            ISagaRepository<AccountSaga> repository = new InMemorySagaRepository<AccountSaga>();

            using (IServiceBus bus = ServiceBusFactory.New(x =>
                {
                    x.UseRabbitMqRouting();

                    x.ReceiveFrom("rabbitmq://localhost/ddon/server");

                    x.Subscribe(s =>
                        {
                            s.Instance(new AccountStatusConsumer());

                            s.Saga<AccountSaga>(repository);
                        });
                }))
            {
                Console.WriteLine("Ready to rock...");


                Console.ReadKey();
            }
        }
    }
}