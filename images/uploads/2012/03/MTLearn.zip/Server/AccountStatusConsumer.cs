namespace Server
{
    using System;
    using MassTransit;
    using Messages;


    public interface IRepository
    {
    }

    public class AccountStatusConsumer :
        Consumes<QueryAccountStatus>.Context
    {

        public void Consume(IConsumeContext<QueryAccountStatus> context)
        {
            Console.WriteLine("Received request for {0}",
                context.Message.AccountId);

            var response = new AccountStatusImpl(context.Message.AccountId, 42.27m);
            context.Respond(response);
        }
    }
}