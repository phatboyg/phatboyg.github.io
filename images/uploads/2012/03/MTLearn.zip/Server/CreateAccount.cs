namespace Server
{
    public class CreateAccount
    {
        public string AccountId { get; set; }
    }
}