﻿namespace Server
{
    using System;
    using Magnum.StateMachine;
    using MassTransit;
    using MassTransit.Saga;

    public class AccountSaga :
        SagaStateMachine<AccountSaga>, ISaga
    {
        public AccountSaga()
        {
        }

        static AccountSaga()
        {
            Define(() =>
                {
                    Correlate(AccountCreated)
                        .By((saga, message) => saga.AccountId == message.AccountId);

                    Initially(
                        When(AccountCreated)
                            .Then((instance, msg) =>
                                {
                                    instance.AccountId = msg.AccountId;
                                })
                            .TransitionTo(Active));
                });
        }

        protected string AccountId { get; set; }

        public AccountSaga(Guid correlationId)
        {
            CorrelationId = correlationId;
        }

        public Guid CorrelationId { get; private set; }
      
        public IServiceBus Bus { get;  set; }

        public static State Initial { get; set; }
        public static State Completed { get; set; }
        public static State Active { get; set; }
        
        public static Event<CreateAccount> AccountCreated { get; set; 
        }
    }
}