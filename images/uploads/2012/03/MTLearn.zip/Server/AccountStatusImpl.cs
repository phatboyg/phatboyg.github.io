namespace Server
{
    using Messages;

    public class AccountStatusImpl :
        AccountStatus,
        AccountAudit
    {
        public AccountStatusImpl(string accountId, decimal balance)
        {
            AccountId = accountId;
            Balance = balance;
        }

        public string AccountId { get; private set; }
        public decimal Balance { get; private set; }
    }
}