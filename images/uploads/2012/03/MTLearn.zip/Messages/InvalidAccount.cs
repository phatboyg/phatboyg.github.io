namespace Messages
{
    public class InvalidAccount
    {
    }
}