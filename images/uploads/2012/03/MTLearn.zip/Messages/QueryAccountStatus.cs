﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Messages
{
    public class QueryAccountStatus
    {
        public QueryAccountStatus(string accountId)
        {
            AccountId = accountId;
        }

        public string AccountId { get; private set; }
    }
}
