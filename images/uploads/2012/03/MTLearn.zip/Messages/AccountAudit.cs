namespace Messages
{
    public interface AccountAudit
    {
        string AccountId { get; }
    }
}