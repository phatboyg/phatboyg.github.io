namespace Messages
{
    public interface AccountStatus
    {
        string AccountId { get; }
        decimal Balance { get; }
    }
}