﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Client
{
    using Magnum.Extensions;
    using MassTransit;
    using Messages;

    class Program
    {
        static void Main(string[] args)
        {

            using (IServiceBus bus = ServiceBusFactory.New(x =>
            {
                x.UseRabbitMqRouting();

                x.ReceiveFrom("rabbitmq://localhost/ddon/client");

                x.Subscribe(s =>
                    {
                        s.Handler<AccountAudit>(message =>
                            {
                                Console.WriteLine("Audit: {0}", message.AccountId);
                            });
                    });
            }))
            {
                Console.WriteLine("Sending request...");

                bus.PublishRequest(new QueryAccountStatus("123"), x =>
                    {
                        x.Handle<AccountStatus>(message =>
                            {
                                Console.WriteLine("Balance: {0}", message.Balance);
                            });
                        x.Handle<InvalidAccount>(message =>
                            {
                                
                            });
                    });

                Console.ReadKey();
            }
        }
    }
}
