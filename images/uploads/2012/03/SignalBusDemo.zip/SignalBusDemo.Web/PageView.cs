﻿namespace SignalBusDemo.Web
{
    using SignalR.Hubs;

    public class PageView :
        Hub
    {
        public void UpdatePageView()
        {
        }
    }


    public class SomeResult
    {
        public string Status { get; set; }

        public string OrderId { get; set; }
    }
}