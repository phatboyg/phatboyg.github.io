namespace SignalBusDemo.Web
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Mvc;
    using System.Web.Routing;
    using MassTransit;

    public class CustomDependencyResolver :
        IDependencyResolver
    {
        readonly IDependencyResolver _delegateDependencyResolver;

        public CustomDependencyResolver(IDependencyResolver delegateDependencyResolver)
        {
            _delegateDependencyResolver = delegateDependencyResolver;
        }

        public object GetService(Type serviceType)
        {
            if (serviceType == typeof(IServiceBus))
                return Bus.Instance;

            return _delegateDependencyResolver.GetService(serviceType);
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            if (serviceType == typeof(IServiceBus))
                return Enumerable.Repeat(Bus.Instance, 1);

            return _delegateDependencyResolver.GetServices(serviceType);
        }
    }

    public class CustomControllerActivator :
        IControllerActivator
    {
        IController IControllerActivator.Create(
            RequestContext requestContext,
            Type controllerType)
        {
            return DependencyResolver.Current
                       .GetService(controllerType) as IController;
        }
    }
}