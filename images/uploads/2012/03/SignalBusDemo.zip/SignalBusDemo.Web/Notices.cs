namespace SignalBusDemo.Web
{
    using SignalR.Hubs;

    public class Notices :
        Hub
    {

        public void Send(string message)
        {
            Clients.notify(message);
        }
    }
}