namespace SignalBusDemo.Web
{
    using System;
    using System.Threading.Tasks;
    using Magnum.Extensions;
    using MassTransit;
    using Messages;
    using SignalR.Hubs;

    public class OrderService :
        Hub
    {

        public SomeResult GetOrder(string orderId)
        {
            return new SomeResult {OrderId = orderId, Status = "Unavailable"};
        }

        public Task<SomeResult> GetOrderStatus(string orderId)
        {
            var source = new TaskCompletionSource<SomeResult>();
            AsyncCallback callback = cb =>
                {
                    try
                    {
                    }
                    catch (Exception ex)
                    {
                        source.SetException(ex);
                        throw;
                    }
                };

            Bus.Instance.BeginPublishRequest(new QueryOrderStatus(orderId), callback, null, x =>
                {
                    x.Handle<OrderStatusResult>(message =>
                        {
                            source.SetResult(new SomeResult
                                {
                                    OrderId = message.OrderId,
                                    Status = message.Status,
                                });
                        });
                    x.SetTimeout(30.Seconds());
                });

            return source.Task;
        }
    }
}