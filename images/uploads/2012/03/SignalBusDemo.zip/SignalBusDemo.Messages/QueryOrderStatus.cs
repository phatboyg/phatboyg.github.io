namespace SignalBusDemo.Messages
{
    public class QueryOrderStatus
    {
        public string OrderId { get; private set; }

        public QueryOrderStatus(string orderId)
        {
            OrderId = orderId;
        }
    }
}