namespace SignalBusDemo.Messages
{
    public class OrderStatusResult
    {
        public OrderStatusResult(string orderId, string status)
        {
            OrderId = orderId;
            Status = status;
        }

        public string OrderId { get; private set; }
        public string Status { get; private set; }
    }
}