namespace SignalBusDemo.Messages
{
    public class NotifyUsers
    {
        public NotifyUsers(string text)
        {
            Text = text;
        }

        public string Text { get; private set; }
    }
}