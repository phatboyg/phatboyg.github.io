﻿namespace SignalBusDemo.Messages
{
    using System;

    public class IndexViewed
    {
        public IndexViewed(DateTime dateViewed)
        {
            DateViewed = dateViewed;
        }

        public DateTime DateViewed { get; private set; }
    }
}