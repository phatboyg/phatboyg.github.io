﻿namespace SignalBusDemo.Console
{
    using System;
    using MassTransit;
    using Messages;

    class Program
    {
        static void Main(string[] args)
        {
            using (IServiceBus bus = ServiceBusFactory.New(x =>
                {
                    x.UseRabbitMqRouting();
                    x.ReceiveFrom("rabbitmq://localhost/signaldemo/console");


                    x.Subscribe(s =>
                        {
                            s.Handler<IndexViewed>((context, message) =>
                                {
                                    // yeah!
                                    Console.WriteLine("Index viewed at: {0}", message.DateViewed.ToLongTimeString());
                                });


                            s.Consumer<OrderStatusConsumer>();
                        });
                }))
            {
                Console.WriteLine("Ready to rock...");


                bool keepGoing = true;
                do
                {
                    string line = "";
                    try
                    {
                        Console.Write("> ");
                        Console.Out.Flush();

                        line = Console.ReadLine();
                        if (line.Trim().Length == 0)
                            continue;

                        keepGoing = ProcessLine(bus, line);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Exception processing: {0} {1}", line, ex);
                    }
                }
                while (keepGoing);
            }

            Console.WriteLine("End of line.");
        }

        static bool ProcessLine(IServiceBus bus, string line)
        {
            if (string.Compare("quit", line, StringComparison.InvariantCultureIgnoreCase) == 0)
                return false;

            var message = new NotifyUsers(line);

            bus.Publish(message);

            Console.WriteLine("Send notification to users: {0}", line);
            return true;
        }
    }
}