namespace SignalBusDemo.Console
{
    using System;
    using MassTransit;
    using Messages;

    class OrderStatusConsumer :
        Consumes<QueryOrderStatus>.Context
    {
        public void Consume(IConsumeContext<QueryOrderStatus> context)
        {
            Console.WriteLine("Returning order status for {0}", context.Message.OrderId);

            context.Respond(new OrderStatusResult(context.Message.OrderId, "Pending"));
        }
    }
}