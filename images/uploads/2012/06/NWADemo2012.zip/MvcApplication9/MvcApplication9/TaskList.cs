﻿namespace MvcApplication9
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using SignalR.Hubs;

    public class TaskList :
        Hub
    {
        static readonly IList<string> _items = new List<string>();

        public void Add(string subject)
        {
            _items.Add(subject);

            Clients.taskAdded(subject);
        }

        public Task<string[]> Hello()
        {
            return new Task<string[]>(() => _items.ToArray());
        }
    }
}