﻿namespace TaskPusher
{
    using System;
    using MassTransit;
    using Messages;

    class Program
    {
        static void Main(string[] args)
        {
            using (IServiceBus bus = ServiceBusFactory.New(x =>
                {
                    x.UseRabbitMqRouting();
                    x.ReceiveFrom("rabbitmq://localhost/walmart_service");
                }))
            {
                while (true)
                {
                    Console.Write("> ");
                    string subject = Console.ReadLine();

                    bus.Publish(new AddTaskImpl {Subject = subject});
                }
            }
        }

        class AddTaskImpl :
            AddTask
        {
            public string Subject { get; set; }
        }
    }
}