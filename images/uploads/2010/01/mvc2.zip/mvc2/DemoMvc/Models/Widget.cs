namespace DemoMvc.Models
{
	public class Widget
	{
		public int Id { get; set; }
		public string Title { get; set; }
	}
}