namespace DemoMvc.Infrastructure
{
	using System;
	using System.Web.Mvc;
	using System.Web.Routing;
	using StructureMap;

	public class StructureMapControllerFactory :
		DefaultControllerFactory
	{
		public override IController CreateController(RequestContext requestContext, string controllerName)
		{
			Type controllerType = base.GetControllerType(requestContext, controllerName);

			return GetControllerInstance(requestContext, controllerType);
		}

		protected override IController GetControllerInstance(RequestContext requestContext, Type controllerType)
		{
			if (controllerType == null)
				return null;

			return ObjectFactory.GetInstance(controllerType) as IController;
		}
	}
}