namespace DemoMvc.Infrastructure
{
	using System;
	using System.Collections;
	using System.Collections.Generic;
	using Abstractions;

	public class InMemoryRepository<T> :
		Repository<T>
		where T : class
	{
		private readonly Func<T, int> _keyConverter;
		private readonly IDictionary<int, T> _items = new Dictionary<int, T>();

		public InMemoryRepository(Func<T, int> keyConverter)
		{
			_keyConverter = keyConverter;
		}

		public T Get(int id)
		{
			T value;
			if (_items.TryGetValue(id, out value))
				return value;

			return default(T);
		}

		public void Add(T item)
		{
			_items.Add(_keyConverter(item), item);
		}

		public IEnumerator<T> GetEnumerator()
		{
			return _items.Values.GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}
	}
}