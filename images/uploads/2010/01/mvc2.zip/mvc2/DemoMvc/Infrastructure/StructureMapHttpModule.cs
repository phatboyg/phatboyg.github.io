namespace DemoMvc.Infrastructure
{
	using System;
	using System.Web;
	using StructureMap.Pipeline;

	public class StructureMapHttpModule :
		IHttpModule
	{
		public void Init(HttpApplication context)
		{
			context.EndRequest += OnEndRequest;
		}

		public void Dispose()
		{
		}

		private static void OnEndRequest(object sender, EventArgs e)
		{
			HttpContextLifecycle.DisposeAndClearAll();
		}
	}
}