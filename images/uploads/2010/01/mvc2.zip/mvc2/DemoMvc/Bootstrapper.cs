namespace DemoMvc
{
	using System;
	using System.Linq;
	using System.Web.Mvc;
	using System.Web.Routing;
	using Abstractions;
	using Infrastructure;
	using Models;
	using StructureMap;
	using StructureMap.Configuration.DSL;
	using StructureMap.Graph;
	using StructureMap.TypeRules;

	public class Bootstrapper
	{
		public void Bootstrap()
		{
			AreaRegistration.RegisterAllAreas();

			RegisterRoutes(RouteTable.Routes);

			BootstrapContainer();
		}

		private static void RegisterRoutes(RouteCollection routes)
		{
			routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

			routes.MapRoute("Default",
			                "{controller}/{action}/{id}",
			                new {controller = "Home", action = "Index", id = ""});
		}

		private static void BootstrapContainer()
		{
			ObjectFactory.Initialize(x =>
				{
					x.SelectConstructor(() => new CookieContainer());

					x.For(typeof (Repository<>)).Singleton().Use(typeof (InMemoryRepository<>));

					BuildUpWidgetRepository(x);

					x.FillAllPropertiesOfType<ITempDataProvider>().Use<NoTempDataProvider>();

					x.Scan(scanner =>
						{
							scanner.TheCallingAssembly();
							scanner.Convention<MatchingInterfaceConvention>();
						});
				});

			ControllerBuilder.Current.SetControllerFactory(ObjectFactory.GetInstance<StructureMapControllerFactory>());
		}

		private static void BuildUpWidgetRepository(IRegistry x)
		{
			x.For<Repository<Widget>>().Singleton().Use(context =>
				{
					return new InMemoryRepository<Widget>(item => item.Id)
						{
							new Widget {Id = 1, Title = "First Item"},
							new Widget {Id = 2, Title = "Second Item"},
							new Widget {Id = 3, Title = "Third Item"},
						};
				});
		}

		private class MatchingInterfaceConvention :
			IRegistrationConvention
		{
			public void Process(Type type, Registry registry)
			{
				if (!type.IsConcrete())
					return;

				Type matchingInterface = type.GetInterfaces()
					.Where(x => x.Name.EndsWith(type.Name))
					.FirstOrDefault();
				if (matchingInterface == null)
					return;

				registry.AddType(matchingInterface, type);
			}
		}
	}
}