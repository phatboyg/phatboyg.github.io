namespace DemoMvc.ViewModels.Widget
{
	public class WidgetListItem
	{
		public int Id { get; set; }
		public string Title { get; set; }
	}
}