namespace DemoMvc.ViewModels.Widget
{
	using System.Collections.Generic;

	public class WidgetListViewModel
	{
		public IList<WidgetListItem> Items { get; set; }
	}
}