namespace DemoMvc.ViewModels.Contact
{
	using System;

	public class IndexViewModel
	{
		public string Name { get; set; }
		public string Email { get; set; }
		public string Subject { get; set; }
		public string Body { get; set; }

		public DateTime SubmittedAt { get; set; }
	}
}