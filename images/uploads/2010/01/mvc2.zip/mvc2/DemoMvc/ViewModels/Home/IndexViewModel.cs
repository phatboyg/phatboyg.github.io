namespace DemoMvc.ViewModels.Home
{
	public class IndexViewModel
	{
	}
}