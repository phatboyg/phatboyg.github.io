﻿function getTimeZoneOffset() {
	var currentDate = new Date();
	var gmtOffset = currentDate.getTimezoneOffset();

	$.cookies.set('timeZoneOffset', '' + gmtOffset, { hoursToLive: 24 });
}

