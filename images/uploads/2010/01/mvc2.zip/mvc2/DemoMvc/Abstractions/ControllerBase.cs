namespace DemoMvc.Abstractions
{
	using System.Web.Mvc;

	public class ControllerBase :
		Controller
	{
		
	}
}