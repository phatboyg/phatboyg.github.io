namespace DemoMvc.Abstractions
{
	using System;

	public interface ICookieContainer
	{
		string GetValue(string key);
		void SetValue(string key, object value, DateTime expires);
		T GetValue<T>(string key);
		bool Exists(string key);
	}
}