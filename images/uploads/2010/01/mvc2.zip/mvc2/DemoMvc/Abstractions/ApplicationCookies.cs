namespace DemoMvc.Abstractions
{
	using System;

	public class ApplicationCookies :
		IApplicationCookies
	{
		private readonly ICookieContainer _cookieContainer;

		public ApplicationCookies(ICookieContainer cookieContainer)
		{
			_cookieContainer = cookieContainer;
		}

		public TimeSpan LocalTimeZoneOffset
		{
			get
			{
				var period = _cookieContainer.GetValue<int>("timeZoneOffset");

				return TimeSpan.FromMinutes(period);
			}
		}

		public DateTime? LastVisit
		{
			get { return _cookieContainer.GetValue<DateTime>("lastVisit"); }
			set { _cookieContainer.SetValue("LastVisit", value, DateTime.Now.AddDays(14)); }
		}
	}
}