namespace DemoMvc.Abstractions
{
	using System.Collections.Generic;

	public interface	Repository<T> :
		IEnumerable<T>
	{
		T Get(int id);
	}
}