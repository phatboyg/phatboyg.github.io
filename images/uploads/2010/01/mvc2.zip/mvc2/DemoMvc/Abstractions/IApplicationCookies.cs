namespace DemoMvc.Abstractions
{
	using System;

	public interface IApplicationCookies
	{
		TimeSpan LocalTimeZoneOffset { get; }
		DateTime? LastVisit { get; set; }
	}
}