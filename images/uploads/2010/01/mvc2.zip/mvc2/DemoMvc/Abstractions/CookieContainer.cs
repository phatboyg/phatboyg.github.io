namespace DemoMvc.Abstractions
{
	using System;
	using System.ComponentModel;
	using System.Globalization;
	using System.Web;

	public class CookieContainer :
		ICookieContainer
	{
		private readonly HttpRequestBase _httpRequest;
		private readonly HttpResponseBase _httpResponse;

		public CookieContainer()
		{
			var httpContext = new HttpContextWrapper(HttpContext.Current);
			_httpRequest = httpContext.Request;
			_httpResponse = httpContext.Response;
		}

		public CookieContainer(HttpResponseBase httpResponse, HttpRequestBase httpRequest)
		{
			_httpResponse = httpResponse;
			_httpRequest = httpRequest;
		}

		public bool Exists(string key)
		{
			if (key == null)
				throw new ArgumentNullException("key");

			return _httpRequest.Cookies[key] != null;
		}

		public string GetValue(string key)
		{
			if (key == null)
				throw new ArgumentNullException("key");


			HttpCookie cookie = _httpRequest.Cookies[key];
			return cookie != null ? cookie.Value : null;
		}

		public void SetValue(string key, object value, DateTime expires)
		{
			if (key == null)
				throw new ArgumentNullException("key");

			string strValue = CheckAndConvertValue(value);

			var cookie = new HttpCookie(key, strValue) {Expires = expires};
			_httpResponse.Cookies.Set(cookie);
		}

		public T GetValue<T>(string key)
		{
			string val = GetValue(key);

			if (val == null)
				return default(T);

			Type type = typeof (T);
			bool isNullable = type.IsGenericType && type.GetGenericTypeDefinition().Equals(typeof (Nullable<>));
			if (isNullable)
				type = new NullableConverter(type).UnderlyingType;

			return (T) Convert.ChangeType(val, type, CultureInfo.InvariantCulture);
		}

		private static string CheckAndConvertValue(object value)
		{
			if (value == null)
				return null;

			if (value is string)
				return value.ToString();

			// only allow value types and nullable<value types>

			Type type = value.GetType();
			bool isTypeAllowed = false;

			if (type.IsValueType)
				isTypeAllowed = true;
			else
			{
				bool isNullable = type.IsGenericType && type.GetGenericTypeDefinition().Equals(typeof (Nullable<>));
				if (isNullable)
				{
					var converter = new NullableConverter(type);
					Type underlyingType = converter.UnderlyingType;
					if (underlyingType.IsValueType)
						isTypeAllowed = true;
				}
			}

			if (!isTypeAllowed)
				throw new NotSupportedException("Only value types and Nullable<ValueType> are allowed!");

			return (string) Convert.ChangeType(value, typeof (string), CultureInfo.InvariantCulture);
		}
	}
}