﻿namespace DemoMvc.Controllers
{
	using System.Linq;
	using System.Web.Mvc;
	using Abstractions;
	using Models;
	using ViewModels.Widget;

	public class WidgetController :
		Controller
	{
		private readonly Repository<Widget> _repository;

		public WidgetController(Repository<Widget> repository)
		{
			_repository = repository;
		}

		public ActionResult Index()
		{
			var model = new WidgetListViewModel
				{
					Items = _repository.Select(x => new WidgetListItem {Id = x.Id, Title = x.Title}).ToList(),
				};

			return View(model);
		}

		public ActionResult Details(int id)
		{
			Widget widget = _repository.Get(id);

			var model = new WidgetDetailsViewModel
				{
					Id = widget.Id,
					Title = widget.Title,
				};

			return View(model);
		}

		[HttpPost]
		public ActionResult Details(WidgetDetailsViewModel model)
		{
			try
			{
				if(model.Id <= 0)
					ModelState.AddModelError("_FORM", "The identifier for the widget is invalid");

				if(string.IsNullOrEmpty(model.Title))
					ModelState.AddModelError("Title", "The title cannot be blank");

				if (!ModelState.IsValid)
					return View(model);

				Widget widget = _repository.Get(model.Id);
				widget.Title = model.Title;

				return RedirectToAction("Index");
			}
			catch
			{
				return View(model);
			}
		}
	}
}