﻿namespace DemoMvc.Controllers
{
	using System.Web.Mvc;
	using ViewModels.Home;

	public class HomeController :
		Controller
	{
		public ActionResult Index()
		{
			var model = new IndexViewModel
				{	
				};

			return View(model);
		}
	}
}