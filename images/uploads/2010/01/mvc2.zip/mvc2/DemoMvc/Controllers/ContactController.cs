﻿namespace DemoMvc.Controllers
{
	using System;
	using System.Web.Mvc;
	using Abstractions;
	using ViewModels.Contact;

	public class ContactController :
		Controller
	{
		private readonly IApplicationCookies _cookies;

		public ContactController(IApplicationCookies cookies)
		{
			_cookies = cookies;
		}

		[HttpPut]
		public ActionResult Index()
		{
			var model = new IndexViewModel
				{
					
				};

			return View(model);
		}

		public ActionResult Submit(IndexViewModel model)
		{
			var submittedAt = DateTime.UtcNow - _cookies.LocalTimeZoneOffset;

			model.SubmittedAt = submittedAt;

			return View("Success", model);
		}
	}
}