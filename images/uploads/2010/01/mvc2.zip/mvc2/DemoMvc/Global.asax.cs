﻿namespace DemoMvc
{
	using System.Web;

	public class MvcApplication :
		HttpApplication
	{
		protected void Application_Start()
		{
			new Bootstrapper().Bootstrap();
		}
	}
}